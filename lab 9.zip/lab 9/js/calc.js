// const a = 5;
// a = 6; // error
// const arr = [1, 2, 3];
// arr.push(4); // no error
// arr[2] = 6; // no error
// arr = [23]; // error
// const obj = { a: 45 };
// obj.a = 56 + 9; // no error
// obj = { v: 56 };// error


window.addEventListener('load', () => {
 const result = document.getElementById('result');
 const clean = document.getElementById('clean');

 clean.addEventListener('click', () => {
  result.innerText = '';
 });

 const keyboardBtns = document.getElementsByClassName('keyboard-elem');
 // for (let i = 0; i < keyboardBtns.length; i += 1) {
 //  console.log(keyboardBtns[i]);
 //  setTimeout(() => {
 //   keyboardBtns[i].style.backgroundColor = 'yellow';
 //   keyboardBtns[i].style.color = 'black';
 //  }, i * 100);
 // }

 for (const elem of keyboardBtns) {
  elem.addEventListener('click', () => {
   const value = elem.innerText;

   if (['+', '*', '/', '-', '.'].includes(value)) {
    const lastElem = result.innerText[result.innerText.length - 1];
    if (lastElem == value) {
     return;
    }
    if (value == '*' && lastElem == '/') {
     return;
    }
    if (value == '/' && lastElem == '*') {
     return;
    }
   }

   // result.innerText = result.innerText + value;
   result.innerText += value;
  });
 }

 /**
  * i++
  * ++i
  * --i
  * i--
  */
 const history = document.querySelector('#history>ul');
 let results = [];
 const prevResults = localStorage.getItem('results');
 if (prevResults) {
  const elems = JSON.parse(prevResults);
  results.push(...elems);
  for (const resElem of results) {
   const li = document.createElement('li');
   li.innerText = resElem;
   history.appendChild(li);
  }
 }
 document.getElementById('reset').addEventListener('click', () => {
  localStorage.setItem('results', JSON.stringify([]));
  results = [];
  const liElems = document.querySelectorAll('#history li');
  for (const li of liElems) {
   li.remove();
  }
 });

 document.getElementById('exec').addEventListener('click', () => {
  const value = result.innerText;
  const res = eval(value);
  const str = `${value}=${res}`;
  results.push(str);
  localStorage.setItem('results', JSON.stringify(results));
  const li = document.createElement('li');
  li.innerText = str;
  history.appendChild(li);
  result.innerHTML = res;
 });

 document.addEventListener('keypress', (event) => {
  console.log('keypress:', event.key);
  if ("0987654321+-*/.".includes(event.key) == false) {
   return;
  }
  result.innerHTML += event.key;
 });

});