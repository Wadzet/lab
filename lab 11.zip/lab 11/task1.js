function sumOfTwo(num1, num2) {
    return Math.pow(num1 + num2, 2);
}