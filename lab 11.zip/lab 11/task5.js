function getCountOfByClassName(element) {
    return document.getElementsByClassName(element).length;
}